/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package typebuddy;

import java.io.IOException;
import java.net.URL;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.stage.Stage;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.Event;
/**
 *
 * @author HP
 */
public class FXMLDocumentController implements Initializable {
    
    @FXML
    private Button lessons;
    
    @FXML
    private Button practice;
    
    @FXML
    ObservableList options=FXCollections.observableArrayList();
    @FXML
    private ComboBox combobox;
    
    @FXML
    private void handleButton1Action(ActionEvent event)throws IOException {
        System.out.println("Lessons page");
       Parent lesson_page_parent=FXMLLoader.load(getClass().getResource("FXMLLessonspage.fxml"));
       Scene lesson_page_scene=new Scene(lesson_page_parent);
       Stage app_stage=(Stage) ((Node) event.getSource()).getScene().getWindow();
       app_stage.setScene(lesson_page_scene);
       app_stage.show();
    }
   
    @FXML
    private void handleButton2Action(ActionEvent event)throws IOException {
        System.out.println("Practice page");
       Parent lesson_page_parent=FXMLLoader.load(getClass().getResource("FXMLPractice1.fxml"));
       Scene lesson_page_scene=new Scene(lesson_page_parent);
       Stage app_stage=(Stage) ((Node) event.getSource()).getScene().getWindow();
       app_stage.setScene(lesson_page_scene);
       app_stage.show();
    }
    @FXML
    private void handleButton3Action(ActionEvent event)throws IOException {
        System.out.println("Advance Practice page");
       Parent lesson_page_parent=FXMLLoader.load(getClass().getResource("FXMLAPractice.fxml"));
       Scene lesson_page_scene=new Scene(lesson_page_parent);
       Stage app_stage=(Stage) ((Node) event.getSource()).getScene().getWindow();
       app_stage.setScene(lesson_page_scene);
       app_stage.show();
    }
    
    @Override // This method is called by the FXMLLoader when initialization is complete
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
         try{
        Class.forName("oracle.jdbc.driver.OracleDriver");
            Connection con=DriverManager.getConnection( "jdbc:oracle:thin:@localhost:1521:xe","system","hetvi9398");
        ResultSet rs = con.createStatement().executeQuery("select username from typebuddy");
                while(rs.next())
                {
                    options.add(rs.getString("username"));
                }
            
             rs.close();
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(FXMLDocumentController.class.getName()).log(Level.SEVERE, null, ex);
        } catch (SQLException ex) {
            Logger.getLogger(FXMLDocumentController.class.getName()).log(Level.SEVERE, null, ex);
        }
         //combobox.setItems(null);
        combobox.setItems(options);
        System.out.println(options);
        
}
}
    
        
   

