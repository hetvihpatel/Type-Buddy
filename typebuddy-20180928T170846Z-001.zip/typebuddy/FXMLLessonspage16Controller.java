/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package typebuddy;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.animation.Animation;
import javafx.animation.KeyFrame;
import javafx.animation.Timeline;
import javafx.beans.property.IntegerProperty;
import javafx.beans.property.SimpleIntegerProperty;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.stage.Stage;
import javafx.util.Duration;

/**
 * FXML Controller class
 *
 * @author HP
 */
public class FXMLLessonspage16Controller implements Initializable {

    @FXML
    private Button next;
    private Button previous;
    public TextField tf1=new TextField();
    public TextField tf2=new TextField();
    public Label label1;
    private Button done9;
     
    @FXML
    private void handledone9Action(ActionEvent event)throws IOException {
       String s,s1;
       s1=tf1.getText();
        s = tf2.getText();
    /*System.out.println(s);
    System.out.println(s1);*/
    if(s.equals(s1))
    {
        label1.setText("You can move to next module");
    }
    else
    {
        label1.setText("You cannot move to next module");
    }
    timeline.stop();//stop the timmer
    }
    @FXML
    private static final int STARTTIME = 0;
    private Timeline timeline;
   
    private final IntegerProperty timeSeconds = new SimpleIntegerProperty(STARTTIME);
    @FXML
     private Label timerLabel;
    
    public void updateTime(){//initialize the timmer
            //increment seconds
            int seconds=timeSeconds.get();
            timeSeconds.set(seconds+1);
        }  
    @FXML
    private void handlenext16Action(ActionEvent event)throws IOException {
        
       Parent lesson_page1_parent=FXMLLoader.load(getClass().getResource("FXMLLessonspage17.fxml"));
       Scene lesson_page1_scene=new Scene(lesson_page1_parent);
       Stage app_stage=(Stage) ((Node) event.getSource()).getScene().getWindow();
       app_stage.setScene(lesson_page1_scene);
       app_stage.show();
    }
    @FXML
    private void handleprevious16Action(ActionEvent event)throws IOException {
        
       Parent lesson_page1_parent=FXMLLoader.load(getClass().getResource("FXMLLessonspage15.fxml"));
       Scene lesson_page1_scene=new Scene(lesson_page1_parent);
       Stage app_stage=(Stage) ((Node) event.getSource()).getScene().getWindow();
       app_stage.setScene(lesson_page1_scene);
       app_stage.show();
    }
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
        tf2.setOnMouseClicked(e -> {//start the timmer on mouse click on textfield
            
            timeline = new Timeline(new KeyFrame(Duration.seconds(1),evt -> updateTime()));
               
                timeline.setCycleCount(Animation.INDEFINITE);
                timeSeconds.set(STARTTIME);
                
                timeline.play();
        }
                 
         );
        timerLabel.textProperty().bind(timeSeconds.asString());
        tf2.setOnAction(e -> {  //stop the timmer on pressing the enter key
            String s,s1;
       s1=tf1.getText();
        s = tf2.getText();
   
    if(s.equals(s1))
    {
        label1.setText("You can move to next module");
    }
    else
    {
        label1.setText("You cannot move to next module");
    }
    timeline.stop();
        }
        );   
    }    
    
}
