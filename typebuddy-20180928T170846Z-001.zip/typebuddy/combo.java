/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package typebuddy;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.control.ComboBox;

/**
 *
 * @author HP
 */
public class combo {
   @FXML
    ObservableList options=FXCollections.observableArrayList();
    @FXML
    private ComboBox combobox;
   
    
    public void fillcombo(){
       try{
        Class.forName("oracle.jdbc.driver.OracleDriver");
            Connection con=DriverManager.getConnection( "jdbc:oracle:thin:@localhost:1521:xe","system","hetvi9398");
        ResultSet rs = con.createStatement().executeQuery("SELECT username FROM typebuddy;");
                while(rs.next())
                {
                    options.add(rs.getString(2));
                }
            
             rs.close();
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(FXMLDocumentController.class.getName()).log(Level.SEVERE, null, ex);
        } catch (SQLException ex) {
            Logger.getLogger(FXMLDocumentController.class.getName()).log(Level.SEVERE, null, ex);
        }
         //combobox.setItems(null);
        combobox.setItems(options);
   }
}
